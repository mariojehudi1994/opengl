
#include <GL/gl.h>
#include <GL/glut.h>
#include <math.h>



void tablero(void)
{
	glTranslatef(0.5, -3.90, 0.9);
    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(0.0f,0.0f,0.0f);
    glVertex3f(0.0f,3.0f,0.0f);
    glVertex3f(3.0f,3.0f,0.0f);
    glVertex3f(3.0f,0.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(3.0f,0.0f,0.0f);
    glVertex3f(3.0f,3.0f,0.0f);
    glVertex3f(6.0f,3.0f,0.0f);
    glVertex3f(6.0f,0.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(6.0f,0.0f,0.0f);
    glVertex3f(6.0f,3.0f,0.0f);
    glVertex3f(9.0f,3.0f,0.0f);
    glVertex3f(9.0f,0.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(9.0f,0.0f,0.0f);
    glVertex3f(9.0f,3.0f,0.0f);
    glVertex3f(12.0f,3.0f,0.0f);
    glVertex3f(12.0f,0.0f,0.0f);
    glEnd();

  //Cuadrante 2
    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(0.0f,0.0f,0.0f);
    glVertex3f(0.0f,3.0f,0.0f);
    glVertex3f(-3.0f,3.0f,0.0f);
    glVertex3f(-3.0f,0.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(-3.0f,0.0f,0.0f);
    glVertex3f(-3.0f,3.0f,0.0f);
    glVertex3f(-6.0f,3.0f,0.0f);
    glVertex3f(-6.0f,0.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(-6.0f,0.0f,0.0f);
    glVertex3f(-6.0f,3.0f,0.0f);
    glVertex3f(-9.0f,3.0f,0.0f);
    glVertex3f(-9.0f,0.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(-9.0f,0.0f,0.0f);
    glVertex3f(-9.0f,3.0f,0.0f);
    glVertex3f(-12.0f,3.0f,0.0f);
    glVertex3f(-12.0f,0.0f,0.0f);
    glEnd();

  //Segunda fila
    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(0.0f,3.0f,0.0f);
    glVertex3f(3.0f,3.0f,0.0f);
    glVertex3f(3.0f,6.0f,0.0f);
    glVertex3f(0.0f,6.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(3.0f,3.0f,0.0f);
    glVertex3f(6.0f,3.0f,0.0f);
    glVertex3f(6.0f,6.0f,0.0f);
    glVertex3f(3.0f,6.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(6.0f,3.0f,0.0f);
    glVertex3f(9.0f,3.0f,0.0f);
    glVertex3f(9.0f,6.0f,0.0f);
    glVertex3f(6.0f,6.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(9.0f,3.0f,0.0f);
    glVertex3f(12.0f,3.0f,0.0f);
    glVertex3f(12.0f,6.0f,0.0f);
    glVertex3f(9.0f,6.0f,0.0f);
    glEnd();

  //tercer fila
    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(0.0f,6.0f,0.0f);
    glVertex3f(3.0f,6.0f,0.0f);
    glVertex3f(3.0f,9.0f,0.0f);
    glVertex3f(0.0f,9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(3.0f,6.0f,0.0f);
    glVertex3f(6.0f,6.0f,0.0f);
    glVertex3f(6.0f,9.0f,0.0f);
    glVertex3f(3.0f,9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(6.0f,6.0f,0.0f);
    glVertex3f(9.0f,6.0f,0.0f);
    glVertex3f(9.0f,9.0f,0.0f);
    glVertex3f(6.0f,9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(9.0f,6.0f,0.0f);
    glVertex3f(12.0f,6.0f,0.0f);
    glVertex3f(12.0f,9.0f,0.0f);
    glVertex3f(9.0f,9.0f,0.0f);
    glEnd();


//tercer fila
    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(0.0f,6.0f,0.0f);
    glVertex3f(3.0f,6.0f,0.0f);
    glVertex3f(3.0f,9.0f,0.0f);
    glVertex3f(0.0f,9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(3.0f,6.0f,0.0f);
    glVertex3f(6.0f,6.0f,0.0f);
    glVertex3f(6.0f,9.0f,0.0f);
    glVertex3f(3.0f,9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(6.0f,6.0f,0.0f);
    glVertex3f(9.0f,6.0f,0.0f);
    glVertex3f(9.0f,9.0f,0.0f);
    glVertex3f(6.0f,9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(9.0f,6.0f,0.0f);
    glVertex3f(12.0f,6.0f,0.0f);
    glVertex3f(12.0f,9.0f,0.0f);
    glVertex3f(9.0f,9.0f,0.0f);
    glEnd();

  //Segunda fila
    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(-0.0f,3.0f,0.0f);
    glVertex3f(-3.0f,3.0f,0.0f);
    glVertex3f(-3.0f,6.0f,0.0f);
    glVertex3f(-0.0f,6.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(-3.0f,3.0f,0.0f);
    glVertex3f(-6.0f,3.0f,0.0f);
    glVertex3f(-6.0f,6.0f,0.0f);
    glVertex3f(-3.0f,6.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(-6.0f,3.0f,0.0f);
    glVertex3f(-9.0f,3.0f,0.0f);
    glVertex3f(-9.0f,6.0f,0.0f);
    glVertex3f(-6.0f,6.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(-9.0f,3.0f,0.0f);
    glVertex3f(-12.0f,3.0f,0.0f);
    glVertex3f(-12.0f,6.0f,0.0f);
    glVertex3f(-9.0f,6.0f,0.0f);
    glEnd();


  //tercer fila
    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(0.0f,6.0f,0.0f);
    glVertex3f(3.0f,6.0f,0.0f);
    glVertex3f(3.0f,9.0f,0.0f);
    glVertex3f(0.0f,9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(3.0f,6.0f,0.0f);
    glVertex3f(6.0f,6.0f,0.0f);
    glVertex3f(6.0f,9.0f,0.0f);
    glVertex3f(3.0f,9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(6.0f,6.0f,0.0f);
    glVertex3f(9.0f,6.0f,0.0f);
    glVertex3f(9.0f,9.0f,0.0f);
    glVertex3f(6.0f,9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(9.0f,6.0f,0.0f);
    glVertex3f(12.0f,6.0f,0.0f);
    glVertex3f(12.0f,9.0f,0.0f);
    glVertex3f(9.0f,9.0f,0.0f);
    glEnd();


  //tercer fila
    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(0.0f,6.0f,0.0f);
    glVertex3f(-3.0f,6.0f,0.0f);
    glVertex3f(-3.0f,9.0f,0.0f);
    glVertex3f(0.0f,9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0,1.0);
    glVertex3f(-3.0f,6.0f,0.0f);
    glVertex3f(-6.0f,6.0f,0.0f);
    glVertex3f(-6.0f,9.0f,0.0f);
    glVertex3f(-3.0f,9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(-6.0f,6.0f,0.0f);
    glVertex3f(-9.0f,6.0f,0.0f);
    glVertex3f(-9.0f,9.0f,0.0f);
    glVertex3f(-6.0f,9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(-9.0f,6.0f,0.0f);
    glVertex3f(-12.0f,6.0f,0.0f);
    glVertex3f(-12.0f,9.0f,0.0f);
    glVertex3f(-9.0f,9.0f,0.0f);
    glEnd();

    

/***************************************************************************************************/
 //Cudrante 3 y 4 

  //Cuadradrados cuadrante 4
    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(0.0f,0.0f,0.0f);
    glVertex3f(0.0f,-3.0f,0.0f);
    glVertex3f(-3.0f,-3.0f,0.0f);
    glVertex3f(-3.0f,0.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(-3.0f,0.0f,0.0f);
    glVertex3f(-3.0f,-3.0f,0.0f);
    glVertex3f(-6.0f,-3.0f,0.0f);
    glVertex3f(-6.0f,0.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(-6.0f,0.0f,0.0f);
    glVertex3f(-6.0f,-3.0f,0.0f);
    glVertex3f(-9.0f,-3.0f,0.0f);
    glVertex3f(-9.0f,0.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(-9.0f,0.0f,0.0f);
    glVertex3f(-9.0f,-3.0f,0.0f);
    glVertex3f(-12.0f,-3.0f,0.0f);
    glVertex3f(-12.0f,0.0f,0.0f);
    glEnd();

  //Segunda fila negativa
    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(-0.0f,-3.0f,0.0f);
    glVertex3f(-3.0f,-3.0f,0.0f);
    glVertex3f(-3.0f,-6.0f,0.0f);
    glVertex3f(-0.0f,-6.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0,1.0);
    glVertex3f(-3.0f,-3.0f,0.0f);
    glVertex3f(-6.0f,-3.0f,0.0f);
    glVertex3f(-6.0f,-6.0f,0.0f);
    glVertex3f(-3.0f,-6.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(-6.0f,-3.0f,0.0f);
    glVertex3f(-9.0f,-3.0f,0.0f);
    glVertex3f(-9.0f,-6.0f,0.0f);
    glVertex3f(-6.0f,-6.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(-9.0f,-3.0f,0.0f);
    glVertex3f(-12.0f,-3.0f,0.0f);
    glVertex3f(-12.0f,-6.0f,0.0f);
    glVertex3f(-9.0f,-6.0f,0.0f);
    glEnd();

  //cuadrante 3
    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(0.0f,0.0f,0.0f);
    glVertex3f(0.0f,-3.0f,0.0f);
    glVertex3f(3.0f,-3.0f,0.0f);
    glVertex3f(3.0f,0.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(3.0f,0.0f,0.0f);
    glVertex3f(3.0f,-3.0f,0.0f);
    glVertex3f(6.0f,-3.0f,0.0f);
    glVertex3f(6.0f,0.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(6.0f,0.0f,0.0f);
    glVertex3f(6.0f,-3.0f,0.0f);
    glVertex3f(9.0f,-3.0f,0.0f);
    glVertex3f(9.0f,0.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(9.0f,0.0f,0.0f);
    glVertex3f(9.0f,-3.0f,0.0f);
    glVertex3f(12.0f,-3.0f,0.0f);
    glVertex3f(12.0f,0.0f,0.0f);
    glEnd();

  //Segunda fila negativa
    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(0.0f,-3.0f,0.0f);
    glVertex3f(3.0f,-3.0f,0.0f);
    glVertex3f(3.0f,-6.0f,0.0f);
    glVertex3f(0.0f,-6.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(3.0f,-3.0f,0.0f);
    glVertex3f(6.0f,-3.0f,0.0f);
    glVertex3f(6.0f,-6.0f,0.0f);
    glVertex3f(3.0f,-6.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(6.0f,-3.0f,0.0f);
    glVertex3f(9.0f,-3.0f,0.0f);
    glVertex3f(9.0f,-6.0f,0.0f);
    glVertex3f(6.0f,-6.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(9.0f,-3.0f,0.0f);
    glVertex3f(12.0f,-3.0f,0.0f);
    glVertex3f(12.0f,-6.0f,0.0f);
    glVertex3f(9.0f,-6.0f,0.0f);
    glEnd();
/*******/

  //tercer fila
    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(0.0f,-6.0f,0.0f);
    glVertex3f(-3.0f,-6.0f,0.0f);
    glVertex3f(-3.0f,-9.0f,0.0f);
    glVertex3f(0.0f,-9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(-3.0f,-6.0f,0.0f);
    glVertex3f(-6.0f,-6.0f,0.0f);
    glVertex3f(-6.0f,-9.0f,0.0f);
    glVertex3f(-3.0f,-9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(-6.0f,-6.0f,0.0f);
    glVertex3f(-9.0f,-6.0f,0.0f);
    glVertex3f(-9.0f,-9.0f,0.0f);
    glVertex3f(-6.0f,-9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(-9.0f,-6.0f,0.0f);
    glVertex3f(-12.0f,-6.0f,0.0f);
    glVertex3f(-12.0f,-9.0f,0.0f);
    glVertex3f(-9.0f,-9.0f,0.0f);
    glEnd();


  //Segunda fila negativa
    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(0.0f,-6.0f,0.0f);
    glVertex3f(3.0f,-6.0f,0.0f);
    glVertex3f(3.0f,-9.0f,0.0f);
    glVertex3f(0.0f,-9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0,1.0);
    glVertex3f(3.0f,-6.0f,0.0f);
    glVertex3f(6.0f,-6.0f,0.0f);
    glVertex3f(6.0f,-9.0f,0.0f);
    glVertex3f(3.0f,-9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(6.0f,-6.0f,0.0f);
    glVertex3f(9.0f,-6.0f,0.0f);
    glVertex3f(9.0f,-9.0f,0.0f);
    glVertex3f(6.0f,-9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(9.0f,-6.0f,0.0f);
    glVertex3f(12.0f,-6.0f,0.0f);
    glVertex3f(12.0f,-9.0f,0.0f);
    glVertex3f(9.0f,-9.0f,0.0f);
    glEnd();


  //cuarta fila
    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(0.0f,9.0f,0.0f);
    glVertex3f(-3.0f,9.0f,0.0f);
    glVertex3f(-3.0f,12.0f,0.0f);
    glVertex3f(0.0f,12.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(-3.0f,9.0f,0.0f);
    glVertex3f(-6.0f,9.0f,0.0f);
    glVertex3f(-6.0f,12.0f,0.0f);
    glVertex3f(-3.0f,12.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(-6.0f,9.0f,0.0f);
    glVertex3f(-9.0f,9.0f,0.0f);
    glVertex3f(-9.0f,12.0f,0.0f);
    glVertex3f(-6.0f,12.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(-9.0f,9.0f,0.0f);
    glVertex3f(-12.0f,9.0f,0.0f);
    glVertex3f(-12.0f,12.0f,0.0f);
    glVertex3f(-9.0f,12.0f,0.0f);
    glEnd();


  //cuarta fila 2
    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(0.0f,9.0f,0.0f);
    glVertex3f(3.0f,9.0f,0.0f);
    glVertex3f(3.0f,12.0f,0.0f);
    glVertex3f(0.0f,12.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0,1.0);
    glVertex3f(3.0f,9.0f,0.0f);
    glVertex3f(6.0f,9.0f,0.0f);
    glVertex3f(6.0f,12.0f,0.0f);
    glVertex3f(3.0f,12.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(6.0f,9.0f,0.0f);
    glVertex3f(9.0f,9.0f,0.0f);
    glVertex3f(9.0f,12.0f,0.0f);
    glVertex3f(6.0f,12.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(9.0f,9.0f,0.0f);
    glVertex3f(12.0f,9.0f,0.0f);
    glVertex3f(12.0f,12.0f,0.0f);
    glVertex3f(9.0f,12.0f,0.0f);
    glEnd();




  //cuarta fila
    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(0.0f,-9.0f,0.0f);
    glVertex3f(-3.0f,-9.0f,0.0f);
    glVertex3f(-3.0f,-12.0f,0.0f);
    glVertex3f(0.0f,-12.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0,1.0);
    glVertex3f(-3.0f,-9.0f,0.0f);
    glVertex3f(-6.0f,-9.0f,0.0f);
    glVertex3f(-6.0f,-12.0f,0.0f);
    glVertex3f(-3.0f,-12.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(-6.0f,-9.0f,0.0f);
    glVertex3f(-9.0f,-9.0f,0.0f);
    glVertex3f(-9.0f,-12.0f,0.0f);
    glVertex3f(-6.0f,-12.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(-9.0f,-9.0f,0.0f);
    glVertex3f(-12.0f,-9.0f,0.0f);
    glVertex3f(-12.0f,-12.0f,0.0f);
    glVertex3f(-9.0f,-12.0f,0.0f);
    glEnd();


//cuarta fila 2 negativa
    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(0.0f,-9.0f,0.0f);
    glVertex3f(3.0f,-9.0f,0.0f);
    glVertex3f(3.0f,-12.0f,0.0f);
    glVertex3f(0.0f,-12.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(3.0f,-9.0f,0.0f);
    glVertex3f(6.0f,-9.0f,0.0f);
    glVertex3f(6.0f,-12.0f,0.0f);
    glVertex3f(3.0f,-12.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(6.0f,-9.0f,0.0f);
    glVertex3f(9.0f,-9.0f,0.0f);
    glVertex3f(9.0f,-12.0f,0.0f);
    glVertex3f(6.0f,-12.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(9.0f,-9.0f,0.0f);
    glVertex3f(12.0f,-9.0f,0.0f);
    glVertex3f(12.0f,-12.0f,0.0f);
    glVertex3f(9.0f,-12.0f,0.0f);
    glEnd();

}


void display(void)
{
    	glClear(GL_COLOR_BUFFER_BIT);
	glLoadIdentity();
	glScalef(1.0,1.0,1.0);
	tablero();
	glFlush();
}

void init(void)
{
	glClearColor(0.0, 0.0, 0.0, 0.0);
	glShadeModel(GL_FLAT);
}

void reshape(int w, int h)
{
	glViewport(0,0,(GLsizei)w,(GLsizei)h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(80.0f, (GLfloat)w/(GLfloat)h, 0.0f, 1.0f);
	//glOrtho(-13.0, 13.0, -13.0, 13.0, -13.0, 13.0);
	gluLookAt(0.0,0.5,-25.0,0.0,0.0,-1.0,0.0,1.0,0.0);	
	glRotatef(45.0, 1.0, 0.0, 0.0);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize (400, 400);//tamaño de la ventana
    glutInitWindowPosition (300, 100);//posicion de la ventana en la pantalla
    glutCreateWindow ("Tablero");//nombre de la ventana
    init ();
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutMainLoop();
    return 0;
}
