#include <GL/gl.h>
#include <GL/glut.h>
#include <math.h>


void base(void){
	
	/*Cuadradrados positivos cuadrante 1*/
    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);//
    glVertex3f(0.0f,0.0f,0.0f);
    glVertex3f(0.0f,3.0f,0.0f);
    glVertex3f(3.0f,3.0f,0.0f);
    glVertex3f(3.0f,0.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(0.0, 0.0, 0.0);//
    glVertex3f(3.0f,0.0f,0.0f);
    glVertex3f(3.0f,3.0f,0.0f);
    glVertex3f(6.0f,3.0f,0.0f);
    glVertex3f(6.0f,0.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(1.0, 1.0, 1.0);//
    glVertex3f(6.0f,0.0f,0.0f);
    glVertex3f(6.0f,3.0f,0.0f);
    glVertex3f(9.0f,3.0f,0.0f);
    glVertex3f(9.0f,0.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(0.0, 0.0, 0.0);//
    glVertex3f(9.0f,0.0f,0.0f);
    glVertex3f(9.0f,3.0f,0.0f);
    glVertex3f(12.0f,3.0f,0.0f);
    glVertex3f(12.0f,0.0f,0.0f);
    glEnd();

/*Parte negativa Cuadrante 2*/
    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(0.0, 0.0, 0.0);//
    glVertex3f(0.0f,0.0f,0.0f);
    glVertex3f(0.0f,3.0f,0.0f);
    glVertex3f(-3.0f,3.0f,0.0f);
    glVertex3f(-3.0f,0.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(1.0, 1.0, 1.0);//
    glVertex3f(-3.0f,0.0f,0.0f);
    glVertex3f(-3.0f,3.0f,0.0f);
    glVertex3f(-6.0f,3.0f,0.0f);
    glVertex3f(-6.0f,0.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(0.0, 0.0, 0.0);//
    glVertex3f(-6.0f,0.0f,0.0f);
    glVertex3f(-6.0f,3.0f,0.0f);
    glVertex3f(-9.0f,3.0f,0.0f);
    glVertex3f(-9.0f,0.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(1.0, 1.0, 1.0);//
    glVertex3f(-9.0f,0.0f,0.0f);
    glVertex3f(-9.0f,3.0f,0.0f);
    glVertex3f(-12.0f,3.0f,0.0f);
    glVertex3f(-12.0f,0.0f,0.0f);
    glEnd();

/*Segunda fila positiva*/
    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(0.0, 0.0, 0.0);//
    glVertex3f(0.0f,3.0f,0.0f);
    glVertex3f(3.0f,3.0f,0.0f);
    glVertex3f(3.0f,6.0f,0.0f);
    glVertex3f(0.0f,6.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(1.0, 1.0, 1.0);//
    glVertex3f(3.0f,3.0f,0.0f);
    glVertex3f(6.0f,3.0f,0.0f);
    glVertex3f(6.0f,6.0f,0.0f);
    glVertex3f(3.0f,6.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(0.0, 0.0, 0.0);//
    glVertex3f(6.0f,3.0f,0.0f);
    glVertex3f(9.0f,3.0f,0.0f);
    glVertex3f(9.0f,6.0f,0.0f);
    glVertex3f(6.0f,6.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(1.0, 1.0, 1.0);//
    glVertex3f(9.0f,3.0f,0.0f);
    glVertex3f(12.0f,3.0f,0.0f);
    glVertex3f(12.0f,6.0f,0.0f);
    glVertex3f(9.0f,6.0f,0.0f);
    glEnd();

/*tercer fila negativa*/
    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(1.0, 1.0, 1.0);//
    glVertex3f(0.0f,6.0f,0.0f);
    glVertex3f(3.0f,6.0f,0.0f);
    glVertex3f(3.0f,9.0f,0.0f);
    glVertex3f(0.0f,9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(0.0, 0.0,0.0);//
    glVertex3f(3.0f,6.0f,0.0f);
    glVertex3f(6.0f,6.0f,0.0f);
    glVertex3f(6.0f,9.0f,0.0f);
    glVertex3f(3.0f,9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(1.0, 1.0, 1.0);//
    glVertex3f(6.0f,6.0f,0.0f);
    glVertex3f(9.0f,6.0f,0.0f);
    glVertex3f(9.0f,9.0f,0.0f);
    glVertex3f(6.0f,9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(0.0, 0.0, 0.0);//
    glVertex3f(9.0f,6.0f,0.0f);
    glVertex3f(12.0f,6.0f,0.0f);
    glVertex3f(12.0f,9.0f,0.0f);
    glVertex3f(9.0f,9.0f,0.0f);
    glEnd();


/*tercer fila */
    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(1.0, 1.0, 1.0);//
    glVertex3f(0.0f,6.0f,0.0f);
    glVertex3f(3.0f,6.0f,0.0f);
    glVertex3f(3.0f,9.0f,0.0f);
    glVertex3f(0.0f,9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(0.0, 0.0,0.0);//
    glVertex3f(3.0f,6.0f,0.0f);
    glVertex3f(6.0f,6.0f,0.0f);
    glVertex3f(6.0f,9.0f,0.0f);
    glVertex3f(3.0f,9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(1.0, 1.0, 1.0);//
    glVertex3f(6.0f,6.0f,0.0f);
    glVertex3f(9.0f,6.0f,0.0f);
    glVertex3f(9.0f,9.0f,0.0f);
    glVertex3f(6.0f,9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(0.0, 0.0, 0.0);//
    glVertex3f(9.0f,6.0f,0.0f);
    glVertex3f(12.0f,6.0f,0.0f);
    glVertex3f(12.0f,9.0f,0.0f);
    glVertex3f(9.0f,9.0f,0.0f);
    glEnd();

	/*Segunda fila negativa*/
    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(1.0, 1.0, 1.0);//
    glVertex3f(-0.0f,3.0f,0.0f);
    glVertex3f(-3.0f,3.0f,0.0f);
    glVertex3f(-3.0f,6.0f,0.0f);
    glVertex3f(-0.0f,6.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(0.0, 0.0, 0.0);//
    glVertex3f(-3.0f,3.0f,0.0f);
    glVertex3f(-6.0f,3.0f,0.0f);
    glVertex3f(-6.0f,6.0f,0.0f);
    glVertex3f(-3.0f,6.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(1.0, 1.0, 1.0);//
    glVertex3f(-6.0f,3.0f,0.0f);
    glVertex3f(-9.0f,3.0f,0.0f);
    glVertex3f(-9.0f,6.0f,0.0f);
    glVertex3f(-6.0f,6.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(0.0, 0.0, 0.0);//
    glVertex3f(-9.0f,3.0f,0.0f);
    glVertex3f(-12.0f,3.0f,0.0f);
    glVertex3f(-12.0f,6.0f,0.0f);
    glVertex3f(-9.0f,6.0f,0.0f);
    glEnd();


/*tercer fila negativa*/
    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(1.0, 1.0, 1.0);//
    glVertex3f(0.0f,6.0f,0.0f);
    glVertex3f(3.0f,6.0f,0.0f);
    glVertex3f(3.0f,9.0f,0.0f);
    glVertex3f(0.0f,9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(0.0, 0.0,0.0);//
    glVertex3f(3.0f,6.0f,0.0f);
    glVertex3f(6.0f,6.0f,0.0f);
    glVertex3f(6.0f,9.0f,0.0f);
    glVertex3f(3.0f,9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(1.0, 1.0, 1.0);//
    glVertex3f(6.0f,6.0f,0.0f);
    glVertex3f(9.0f,6.0f,0.0f);
    glVertex3f(9.0f,9.0f,0.0f);
    glVertex3f(6.0f,9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(0.0, 0.0, 0.0);//
    glVertex3f(9.0f,6.0f,0.0f);
    glVertex3f(12.0f,6.0f,0.0f);
    glVertex3f(12.0f,9.0f,0.0f);
    glVertex3f(9.0f,9.0f,0.0f);
    glEnd();


/*tercer fila */
    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(0.0, 0.0, 0.0);//
    glVertex3f(0.0f,6.0f,0.0f);
    glVertex3f(-3.0f,6.0f,0.0f);
    glVertex3f(-3.0f,9.0f,0.0f);
    glVertex3f(0.0f,9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(1.0, 1.0,1.0);//
    glVertex3f(-3.0f,6.0f,0.0f);
    glVertex3f(-6.0f,6.0f,0.0f);
    glVertex3f(-6.0f,9.0f,0.0f);
    glVertex3f(-3.0f,9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(0.0, 0.0, 0.0);//
    glVertex3f(-6.0f,6.0f,0.0f);
    glVertex3f(-9.0f,6.0f,0.0f);
    glVertex3f(-9.0f,9.0f,0.0f);
    glVertex3f(-6.0f,9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(1.0, 1.0, 1.0);//
    glVertex3f(-9.0f,6.0f,0.0f);
    glVertex3f(-12.0f,6.0f,0.0f);
    glVertex3f(-12.0f,9.0f,0.0f);
    glVertex3f(-9.0f,9.0f,0.0f);
    glEnd();

    

/***************************************************************************************************/
/*Cudrante 3 y 4 */

/*Cuadradrados cuadrante 4*/
    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(1.0, 1.0, 1.0);//
    glVertex3f(0.0f,0.0f,0.0f);
    glVertex3f(0.0f,-3.0f,0.0f);
    glVertex3f(-3.0f,-3.0f,0.0f);
    glVertex3f(-3.0f,0.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(0.0, 0.0, 0.0);//
    glVertex3f(-3.0f,0.0f,0.0f);
    glVertex3f(-3.0f,-3.0f,0.0f);
    glVertex3f(-6.0f,-3.0f,0.0f);
    glVertex3f(-6.0f,0.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(1.0, 1.0, 1.0);//
    glVertex3f(-6.0f,0.0f,0.0f);
    glVertex3f(-6.0f,-3.0f,0.0f);
    glVertex3f(-9.0f,-3.0f,0.0f);
    glVertex3f(-9.0f,0.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(0.0, 0.0, 0.0);//
    glVertex3f(-9.0f,0.0f,0.0f);
    glVertex3f(-9.0f,-3.0f,0.0f);
    glVertex3f(-12.0f,-3.0f,0.0f);
    glVertex3f(-12.0f,0.0f,0.0f);
    glEnd();

/*Segunda fila negativa*/
    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(0.0, 0.0, 0.0);//
    glVertex3f(-0.0f,-3.0f,0.0f);
    glVertex3f(-3.0f,-3.0f,0.0f);
    glVertex3f(-3.0f,-6.0f,0.0f);
    glVertex3f(-0.0f,-6.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(1.0, 1.0,1.0);//
    glVertex3f(-3.0f,-3.0f,0.0f);
    glVertex3f(-6.0f,-3.0f,0.0f);
    glVertex3f(-6.0f,-6.0f,0.0f);
    glVertex3f(-3.0f,-6.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(0.0, 0.0, 0.0);//
    glVertex3f(-6.0f,-3.0f,0.0f);
    glVertex3f(-9.0f,-3.0f,0.0f);
    glVertex3f(-9.0f,-6.0f,0.0f);
    glVertex3f(-6.0f,-6.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(1.0, 1.0, 1.0);//
    glVertex3f(-9.0f,-3.0f,0.0f);
    glVertex3f(-12.0f,-3.0f,0.0f);
    glVertex3f(-12.0f,-6.0f,0.0f);
    glVertex3f(-9.0f,-6.0f,0.0f);
    glEnd();

/*Cuadradrados cuadrante 3*/
    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(0.0, 0.0, 0.0);//
    glVertex3f(0.0f,0.0f,0.0f);
    glVertex3f(0.0f,-3.0f,0.0f);
    glVertex3f(3.0f,-3.0f,0.0f);
    glVertex3f(3.0f,0.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(1.0, 1.0, 1.0);//
    glVertex3f(3.0f,0.0f,0.0f);
    glVertex3f(3.0f,-3.0f,0.0f);
    glVertex3f(6.0f,-3.0f,0.0f);
    glVertex3f(6.0f,0.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(0.0, 0.0, 0.0);//
    glVertex3f(6.0f,0.0f,0.0f);
    glVertex3f(6.0f,-3.0f,0.0f);
    glVertex3f(9.0f,-3.0f,0.0f);
    glVertex3f(9.0f,0.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(1.0, 1.0, 1.0);//
    glVertex3f(9.0f,0.0f,0.0f);
    glVertex3f(9.0f,-3.0f,0.0f);
    glVertex3f(12.0f,-3.0f,0.0f);
    glVertex3f(12.0f,0.0f,0.0f);
    glEnd();

/*Segunda fila negativa*/
    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(1.0, 1.0, 1.0);//
    glVertex3f(0.0f,-3.0f,0.0f);
    glVertex3f(3.0f,-3.0f,0.0f);
    glVertex3f(3.0f,-6.0f,0.0f);
    glVertex3f(0.0f,-6.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(0.0, 0.0,0.0);//
    glVertex3f(3.0f,-3.0f,0.0f);
    glVertex3f(6.0f,-3.0f,0.0f);
    glVertex3f(6.0f,-6.0f,0.0f);
    glVertex3f(3.0f,-6.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(1.0, 1.0, 1.0);//
    glVertex3f(6.0f,-3.0f,0.0f);
    glVertex3f(9.0f,-3.0f,0.0f);
    glVertex3f(9.0f,-6.0f,0.0f);
    glVertex3f(6.0f,-6.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(0.0, 0.0, 0.0);//
    glVertex3f(9.0f,-3.0f,0.0f);
    glVertex3f(12.0f,-3.0f,0.0f);
    glVertex3f(12.0f,-6.0f,0.0f);
    glVertex3f(9.0f,-6.0f,0.0f);
    glEnd();
/*******/

/*tercer fila negativa*/
    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(1.0, 1.0, 1.0);//
    glVertex3f(0.0f,-6.0f,0.0f);
    glVertex3f(-3.0f,-6.0f,0.0f);
    glVertex3f(-3.0f,-9.0f,0.0f);
    glVertex3f(0.0f,-9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(0.0, 0.0,0.0);//
    glVertex3f(-3.0f,-6.0f,0.0f);
    glVertex3f(-6.0f,-6.0f,0.0f);
    glVertex3f(-6.0f,-9.0f,0.0f);
    glVertex3f(-3.0f,-9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(1.0, 1.0, 1.0);//
    glVertex3f(-6.0f,-6.0f,0.0f);
    glVertex3f(-9.0f,-6.0f,0.0f);
    glVertex3f(-9.0f,-9.0f,0.0f);
    glVertex3f(-6.0f,-9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(0.0, 0.0, 0.0);//
    glVertex3f(-9.0f,-6.0f,0.0f);
    glVertex3f(-12.0f,-6.0f,0.0f);
    glVertex3f(-12.0f,-9.0f,0.0f);
    glVertex3f(-9.0f,-9.0f,0.0f);
    glEnd();


/*Segunda fila negativa*/
    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(0.0, 0.0, 0.0);//
    glVertex3f(0.0f,-6.0f,0.0f);
    glVertex3f(3.0f,-6.0f,0.0f);
    glVertex3f(3.0f,-9.0f,0.0f);
    glVertex3f(0.0f,-9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(1.0, 1.0,1.0);//
    glVertex3f(3.0f,-6.0f,0.0f);
    glVertex3f(6.0f,-6.0f,0.0f);
    glVertex3f(6.0f,-9.0f,0.0f);
    glVertex3f(3.0f,-9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(0.0, 0.0, 0.0);//
    glVertex3f(6.0f,-6.0f,0.0f);
    glVertex3f(9.0f,-6.0f,0.0f);
    glVertex3f(9.0f,-9.0f,0.0f);
    glVertex3f(6.0f,-9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(1.0, 1.0, 1.0);//
    glVertex3f(9.0f,-6.0f,0.0f);
    glVertex3f(12.0f,-6.0f,0.0f);
    glVertex3f(12.0f,-9.0f,0.0f);
    glVertex3f(9.0f,-9.0f,0.0f);
    glEnd();


/*cuarta fila */
    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(1.0, 1.0, 1.0);//
    glVertex3f(0.0f,9.0f,0.0f);
    glVertex3f(-3.0f,9.0f,0.0f);
    glVertex3f(-3.0f,12.0f,0.0f);
    glVertex3f(0.0f,12.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(0.0, 0.0,0.0);//
    glVertex3f(-3.0f,9.0f,0.0f);
    glVertex3f(-6.0f,9.0f,0.0f);
    glVertex3f(-6.0f,12.0f,0.0f);
    glVertex3f(-3.0f,12.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(1.0, 1.0, 1.0);//
    glVertex3f(-6.0f,9.0f,0.0f);
    glVertex3f(-9.0f,9.0f,0.0f);
    glVertex3f(-9.0f,12.0f,0.0f);
    glVertex3f(-6.0f,12.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(0.0, 0.0, 0.0);//
    glVertex3f(-9.0f,9.0f,0.0f);
    glVertex3f(-12.0f,9.0f,0.0f);
    glVertex3f(-12.0f,12.0f,0.0f);
    glVertex3f(-9.0f,12.0f,0.0f);
    glEnd();


/*cuarta fila 2*/
    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(0.0, 0.0, 0.0);//
    glVertex3f(0.0f,9.0f,0.0f);
    glVertex3f(3.0f,9.0f,0.0f);
    glVertex3f(3.0f,12.0f,0.0f);
    glVertex3f(0.0f,12.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(1.0, 1.0,1.0);//
    glVertex3f(3.0f,9.0f,0.0f);
    glVertex3f(6.0f,9.0f,0.0f);
    glVertex3f(6.0f,12.0f,0.0f);
    glVertex3f(3.0f,12.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(0.0, 0.0, 0.0);//
    glVertex3f(6.0f,9.0f,0.0f);
    glVertex3f(9.0f,9.0f,0.0f);
    glVertex3f(9.0f,12.0f,0.0f);
    glVertex3f(6.0f,12.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(1.0, 1.0, 1.0);//
    glVertex3f(9.0f,9.0f,0.0f);
    glVertex3f(12.0f,9.0f,0.0f);
    glVertex3f(12.0f,12.0f,0.0f);
    glVertex3f(9.0f,12.0f,0.0f);
    glEnd();




/*cuarta fila  negativa*/
    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(0.0, 0.0,0.0);//
    glVertex3f(0.0f,-9.0f,0.0f);
    glVertex3f(-3.0f,-9.0f,0.0f);
    glVertex3f(-3.0f,-12.0f,0.0f);
    glVertex3f(0.0f,-12.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(1.0, 1.0,1.0);//
    glVertex3f(-3.0f,-9.0f,0.0f);
    glVertex3f(-6.0f,-9.0f,0.0f);
    glVertex3f(-6.0f,-12.0f,0.0f);
    glVertex3f(-3.0f,-12.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(0.0, 0.0, 0.0);//
    glVertex3f(-6.0f,-9.0f,0.0f);
    glVertex3f(-9.0f,-9.0f,0.0f);
    glVertex3f(-9.0f,-12.0f,0.0f);
    glVertex3f(-6.0f,-12.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(1.0, 1.0, 1.0);//
    glVertex3f(-9.0f,-9.0f,0.0f);
    glVertex3f(-12.0f,-9.0f,0.0f);
    glVertex3f(-12.0f,-12.0f,0.0f);
    glVertex3f(-9.0f,-12.0f,0.0f);
    glEnd();


/*cuarta fila 2 negativa*/
    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(1.0, 1.0, 1.0);//
    glVertex3f(0.0f,-9.0f,0.0f);
    glVertex3f(3.0f,-9.0f,0.0f);
    glVertex3f(3.0f,-12.0f,0.0f);
    glVertex3f(0.0f,-12.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(0.0, 0.0,0.0);//
    glVertex3f(3.0f,-9.0f,0.0f);
    glVertex3f(6.0f,-9.0f,0.0f);
    glVertex3f(6.0f,-12.0f,0.0f);
    glVertex3f(3.0f,-12.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(1.0, 1.0, 1.0);//
    glVertex3f(6.0f,-9.0f,0.0f);
    glVertex3f(9.0f,-9.0f,0.0f);
    glVertex3f(9.0f,-12.0f,0.0f);
    glVertex3f(6.0f,-12.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);//Funcion primitiva cuadrados
    glColor3f(0.0, 0.0, 0.0);//
    glVertex3f(9.0f,-9.0f,0.0f);
    glVertex3f(12.0f,-9.0f,0.0f);
    glVertex3f(12.0f,-12.0f,0.0f);
    glVertex3f(9.0f,-12.0f,0.0f);
    glEnd();
	
	
	}

void Tablero(void)
{
	
	

    //CUADRO DE FONDO	
    glBegin(GL_QUADS);
    glColor3f(0.75, 0.75, 0.75);
    glVertex3d(0.766,0.8,-1);
    glVertex3d(0.817,0.6,0.03);
    glVertex3d(-0.817,0.6,0.03);
    glVertex3d(-0.766,0.8,-1);
    glEnd();


    //CUADRO IZQUIERDA
    glBegin(GL_QUADS);
    glColor3f(0.25, 0.25, 0.25);
    glVertex3d(0.93,-0.295,-1);
    glVertex3d(0.82,-0.78,0.02);
    glVertex3d(0.82,0.61,0.03);
    glVertex3d(0.799,0.9,-1.02);
    glEnd();
    
    //CUADRO DERECHA
    glBegin(GL_QUADS);
    glColor3f(0.25, 0.25, 0.25);
    glVertex3d(-0.93,-0.295,-1);
    glVertex3d(-0.82,-0.78,0.02); 
    glVertex3d(-0.82,0.61,0.03);
    glVertex3d(-0.799,0.9,-1.02);
    glEnd();
}

void display(void)
{
    glClear(GL_COLOR_BUFFER_BIT);
	glLoadIdentity();
	glScalef(15.0,15.0,15.0);
	Tablero();
    glFlush();
    glTranslatef(0.0,-0.05,0.0);
	glScalef(0.072,0.062,0.09);
	base();
	glFlush();
}

void init(void)
{
	glClearColor(0.0, 0.0, 0.0, 0.0);
	glShadeModel(GL_FLAT);
}

void reshape(int w, int h)
{
    glClearColor(0,0,0,0.1);
	glViewport(0,0,(GLsizei)w,(GLsizei)h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(80.0f, (GLfloat)w/(GLfloat)h, 0.0f, 1.0f);
    gluLookAt(0.0,-22.0,-9.0,0.0,3.0,-1.0,0.0,1.0,0.0);	
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize (1000, 800);//tamaño de la ventana
    glutInitWindowPosition (300, 100);//posicion de la ventana en la pantalla
    glutCreateWindow ("Tablero");//nombre de la ventana
    init ();
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutMainLoop();
    return 0;
}
