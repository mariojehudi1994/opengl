#include <GL/gl.h>
#include <GL/glut.h>
#include <math.h>

void piso(void)
{
	glTranslatef(0.5, -3.90, 0.9);
    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(0.0f,0.0f,0.0f);
    glVertex3f(0.0f,3.0f,0.0f);
    glVertex3f(3.0f,3.0f,0.0f);
    glVertex3f(3.0f,0.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(3.0f,0.0f,0.0f);
    glVertex3f(3.0f,3.0f,0.0f);
    glVertex3f(6.0f,3.0f,0.0f);
    glVertex3f(6.0f,0.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(6.0f,0.0f,0.0f);
    glVertex3f(6.0f,3.0f,0.0f);
    glVertex3f(9.0f,3.0f,0.0f);
    glVertex3f(9.0f,0.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(9.0f,0.0f,0.0f);
    glVertex3f(9.0f,3.0f,0.0f);
    glVertex3f(12.0f,3.0f,0.0f);
    glVertex3f(12.0f,0.0f,0.0f);
    glEnd();

  //Cuadrante 2
    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(0.0f,0.0f,0.0f);
    glVertex3f(0.0f,3.0f,0.0f);
    glVertex3f(-3.0f,3.0f,0.0f);
    glVertex3f(-3.0f,0.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(-3.0f,0.0f,0.0f);
    glVertex3f(-3.0f,3.0f,0.0f);
    glVertex3f(-6.0f,3.0f,0.0f);
    glVertex3f(-6.0f,0.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(-6.0f,0.0f,0.0f);
    glVertex3f(-6.0f,3.0f,0.0f);
    glVertex3f(-9.0f,3.0f,0.0f);
    glVertex3f(-9.0f,0.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(-9.0f,0.0f,0.0f);
    glVertex3f(-9.0f,3.0f,0.0f);
    glVertex3f(-12.0f,3.0f,0.0f);
    glVertex3f(-12.0f,0.0f,0.0f);
    glEnd();

  //Segunda fila
    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(0.0f,3.0f,0.0f);
    glVertex3f(3.0f,3.0f,0.0f);
    glVertex3f(3.0f,6.0f,0.0f);
    glVertex3f(0.0f,6.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(3.0f,3.0f,0.0f);
    glVertex3f(6.0f,3.0f,0.0f);
    glVertex3f(6.0f,6.0f,0.0f);
    glVertex3f(3.0f,6.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(6.0f,3.0f,0.0f);
    glVertex3f(9.0f,3.0f,0.0f);
    glVertex3f(9.0f,6.0f,0.0f);
    glVertex3f(6.0f,6.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(9.0f,3.0f,0.0f);
    glVertex3f(12.0f,3.0f,0.0f);
    glVertex3f(12.0f,6.0f,0.0f);
    glVertex3f(9.0f,6.0f,0.0f);
    glEnd();

  //tercer fila
    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(0.0f,6.0f,0.0f);
    glVertex3f(3.0f,6.0f,0.0f);
    glVertex3f(3.0f,9.0f,0.0f);
    glVertex3f(0.0f,9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(3.0f,6.0f,0.0f);
    glVertex3f(6.0f,6.0f,0.0f);
    glVertex3f(6.0f,9.0f,0.0f);
    glVertex3f(3.0f,9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(6.0f,6.0f,0.0f);
    glVertex3f(9.0f,6.0f,0.0f);
    glVertex3f(9.0f,9.0f,0.0f);
    glVertex3f(6.0f,9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(9.0f,6.0f,0.0f);
    glVertex3f(12.0f,6.0f,0.0f);
    glVertex3f(12.0f,9.0f,0.0f);
    glVertex3f(9.0f,9.0f,0.0f);
    glEnd();


//tercer fila
    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(0.0f,6.0f,0.0f);
    glVertex3f(3.0f,6.0f,0.0f);
    glVertex3f(3.0f,9.0f,0.0f);
    glVertex3f(0.0f,9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(3.0f,6.0f,0.0f);
    glVertex3f(6.0f,6.0f,0.0f);
    glVertex3f(6.0f,9.0f,0.0f);
    glVertex3f(3.0f,9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(6.0f,6.0f,0.0f);
    glVertex3f(9.0f,6.0f,0.0f);
    glVertex3f(9.0f,9.0f,0.0f);
    glVertex3f(6.0f,9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(9.0f,6.0f,0.0f);
    glVertex3f(12.0f,6.0f,0.0f);
    glVertex3f(12.0f,9.0f,0.0f);
    glVertex3f(9.0f,9.0f,0.0f);
    glEnd();

  //Segunda fila
    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(-0.0f,3.0f,0.0f);
    glVertex3f(-3.0f,3.0f,0.0f);
    glVertex3f(-3.0f,6.0f,0.0f);
    glVertex3f(-0.0f,6.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(-3.0f,3.0f,0.0f);
    glVertex3f(-6.0f,3.0f,0.0f);
    glVertex3f(-6.0f,6.0f,0.0f);
    glVertex3f(-3.0f,6.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(-6.0f,3.0f,0.0f);
    glVertex3f(-9.0f,3.0f,0.0f);
    glVertex3f(-9.0f,6.0f,0.0f);
    glVertex3f(-6.0f,6.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(-9.0f,3.0f,0.0f);
    glVertex3f(-12.0f,3.0f,0.0f);
    glVertex3f(-12.0f,6.0f,0.0f);
    glVertex3f(-9.0f,6.0f,0.0f);
    glEnd();


  //tercer fila
    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(0.0f,6.0f,0.0f);
    glVertex3f(3.0f,6.0f,0.0f);
    glVertex3f(3.0f,9.0f,0.0f);
    glVertex3f(0.0f,9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(3.0f,6.0f,0.0f);
    glVertex3f(6.0f,6.0f,0.0f);
    glVertex3f(6.0f,9.0f,0.0f);
    glVertex3f(3.0f,9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(6.0f,6.0f,0.0f);
    glVertex3f(9.0f,6.0f,0.0f);
    glVertex3f(9.0f,9.0f,0.0f);
    glVertex3f(6.0f,9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(9.0f,6.0f,0.0f);
    glVertex3f(12.0f,6.0f,0.0f);
    glVertex3f(12.0f,9.0f,0.0f);
    glVertex3f(9.0f,9.0f,0.0f);
    glEnd();


  //tercer fila
    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(0.0f,6.0f,0.0f);
    glVertex3f(-3.0f,6.0f,0.0f);
    glVertex3f(-3.0f,9.0f,0.0f);
    glVertex3f(0.0f,9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0,1.0);
    glVertex3f(-3.0f,6.0f,0.0f);
    glVertex3f(-6.0f,6.0f,0.0f);
    glVertex3f(-6.0f,9.0f,0.0f);
    glVertex3f(-3.0f,9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(-6.0f,6.0f,0.0f);
    glVertex3f(-9.0f,6.0f,0.0f);
    glVertex3f(-9.0f,9.0f,0.0f);
    glVertex3f(-6.0f,9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(-9.0f,6.0f,0.0f);
    glVertex3f(-12.0f,6.0f,0.0f);
    glVertex3f(-12.0f,9.0f,0.0f);
    glVertex3f(-9.0f,9.0f,0.0f);
    glEnd();

    

/***************************************************************************************************/
 //Cudrante 3 y 4 

  //Cuadradrados cuadrante 4
    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(0.0f,0.0f,0.0f);
    glVertex3f(0.0f,-3.0f,0.0f);
    glVertex3f(-3.0f,-3.0f,0.0f);
    glVertex3f(-3.0f,0.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(-3.0f,0.0f,0.0f);
    glVertex3f(-3.0f,-3.0f,0.0f);
    glVertex3f(-6.0f,-3.0f,0.0f);
    glVertex3f(-6.0f,0.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(-6.0f,0.0f,0.0f);
    glVertex3f(-6.0f,-3.0f,0.0f);
    glVertex3f(-9.0f,-3.0f,0.0f);
    glVertex3f(-9.0f,0.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(-9.0f,0.0f,0.0f);
    glVertex3f(-9.0f,-3.0f,0.0f);
    glVertex3f(-12.0f,-3.0f,0.0f);
    glVertex3f(-12.0f,0.0f,0.0f);
    glEnd();

  //Segunda fila negativa
    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(-0.0f,-3.0f,0.0f);
    glVertex3f(-3.0f,-3.0f,0.0f);
    glVertex3f(-3.0f,-6.0f,0.0f);
    glVertex3f(-0.0f,-6.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0,1.0);
    glVertex3f(-3.0f,-3.0f,0.0f);
    glVertex3f(-6.0f,-3.0f,0.0f);
    glVertex3f(-6.0f,-6.0f,0.0f);
    glVertex3f(-3.0f,-6.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(-6.0f,-3.0f,0.0f);
    glVertex3f(-9.0f,-3.0f,0.0f);
    glVertex3f(-9.0f,-6.0f,0.0f);
    glVertex3f(-6.0f,-6.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(-9.0f,-3.0f,0.0f);
    glVertex3f(-12.0f,-3.0f,0.0f);
    glVertex3f(-12.0f,-6.0f,0.0f);
    glVertex3f(-9.0f,-6.0f,0.0f);
    glEnd();

  //cuadrante 3
    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(0.0f,0.0f,0.0f);
    glVertex3f(0.0f,-3.0f,0.0f);
    glVertex3f(3.0f,-3.0f,0.0f);
    glVertex3f(3.0f,0.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(3.0f,0.0f,0.0f);
    glVertex3f(3.0f,-3.0f,0.0f);
    glVertex3f(6.0f,-3.0f,0.0f);
    glVertex3f(6.0f,0.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(6.0f,0.0f,0.0f);
    glVertex3f(6.0f,-3.0f,0.0f);
    glVertex3f(9.0f,-3.0f,0.0f);
    glVertex3f(9.0f,0.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(9.0f,0.0f,0.0f);
    glVertex3f(9.0f,-3.0f,0.0f);
    glVertex3f(12.0f,-3.0f,0.0f);
    glVertex3f(12.0f,0.0f,0.0f);
    glEnd();

  //Segunda fila negativa
    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(0.0f,-3.0f,0.0f);
    glVertex3f(3.0f,-3.0f,0.0f);
    glVertex3f(3.0f,-6.0f,0.0f);
    glVertex3f(0.0f,-6.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(3.0f,-3.0f,0.0f);
    glVertex3f(6.0f,-3.0f,0.0f);
    glVertex3f(6.0f,-6.0f,0.0f);
    glVertex3f(3.0f,-6.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(6.0f,-3.0f,0.0f);
    glVertex3f(9.0f,-3.0f,0.0f);
    glVertex3f(9.0f,-6.0f,0.0f);
    glVertex3f(6.0f,-6.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(9.0f,-3.0f,0.0f);
    glVertex3f(12.0f,-3.0f,0.0f);
    glVertex3f(12.0f,-6.0f,0.0f);
    glVertex3f(9.0f,-6.0f,0.0f);
    glEnd();
/*******/

  //tercer fila
    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(0.0f,-6.0f,0.0f);
    glVertex3f(-3.0f,-6.0f,0.0f);
    glVertex3f(-3.0f,-9.0f,0.0f);
    glVertex3f(0.0f,-9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(-3.0f,-6.0f,0.0f);
    glVertex3f(-6.0f,-6.0f,0.0f);
    glVertex3f(-6.0f,-9.0f,0.0f);
    glVertex3f(-3.0f,-9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(-6.0f,-6.0f,0.0f);
    glVertex3f(-9.0f,-6.0f,0.0f);
    glVertex3f(-9.0f,-9.0f,0.0f);
    glVertex3f(-6.0f,-9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(-9.0f,-6.0f,0.0f);
    glVertex3f(-12.0f,-6.0f,0.0f);
    glVertex3f(-12.0f,-9.0f,0.0f);
    glVertex3f(-9.0f,-9.0f,0.0f);
    glEnd();


  //Segunda fila negativa
    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(0.0f,-6.0f,0.0f);
    glVertex3f(3.0f,-6.0f,0.0f);
    glVertex3f(3.0f,-9.0f,0.0f);
    glVertex3f(0.0f,-9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0,1.0);
    glVertex3f(3.0f,-6.0f,0.0f);
    glVertex3f(6.0f,-6.0f,0.0f);
    glVertex3f(6.0f,-9.0f,0.0f);
    glVertex3f(3.0f,-9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(6.0f,-6.0f,0.0f);
    glVertex3f(9.0f,-6.0f,0.0f);
    glVertex3f(9.0f,-9.0f,0.0f);
    glVertex3f(6.0f,-9.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(9.0f,-6.0f,0.0f);
    glVertex3f(12.0f,-6.0f,0.0f);
    glVertex3f(12.0f,-9.0f,0.0f);
    glVertex3f(9.0f,-9.0f,0.0f);
    glEnd();


  //cuarta fila
    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(0.0f,9.0f,0.0f);
    glVertex3f(-3.0f,9.0f,0.0f);
    glVertex3f(-3.0f,12.0f,0.0f);
    glVertex3f(0.0f,12.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(-3.0f,9.0f,0.0f);
    glVertex3f(-6.0f,9.0f,0.0f);
    glVertex3f(-6.0f,12.0f,0.0f);
    glVertex3f(-3.0f,12.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(-6.0f,9.0f,0.0f);
    glVertex3f(-9.0f,9.0f,0.0f);
    glVertex3f(-9.0f,12.0f,0.0f);
    glVertex3f(-6.0f,12.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(-9.0f,9.0f,0.0f);
    glVertex3f(-12.0f,9.0f,0.0f);
    glVertex3f(-12.0f,12.0f,0.0f);
    glVertex3f(-9.0f,12.0f,0.0f);
    glEnd();


  //cuarta fila 2
    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(0.0f,9.0f,0.0f);
    glVertex3f(3.0f,9.0f,0.0f);
    glVertex3f(3.0f,12.0f,0.0f);
    glVertex3f(0.0f,12.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0,1.0);
    glVertex3f(3.0f,9.0f,0.0f);
    glVertex3f(6.0f,9.0f,0.0f);
    glVertex3f(6.0f,12.0f,0.0f);
    glVertex3f(3.0f,12.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(6.0f,9.0f,0.0f);
    glVertex3f(9.0f,9.0f,0.0f);
    glVertex3f(9.0f,12.0f,0.0f);
    glVertex3f(6.0f,12.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(9.0f,9.0f,0.0f);
    glVertex3f(12.0f,9.0f,0.0f);
    glVertex3f(12.0f,12.0f,0.0f);
    glVertex3f(9.0f,12.0f,0.0f);
    glEnd();




  //cuarta fila
    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(0.0f,-9.0f,0.0f);
    glVertex3f(-3.0f,-9.0f,0.0f);
    glVertex3f(-3.0f,-12.0f,0.0f);
    glVertex3f(0.0f,-12.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0,1.0);
    glVertex3f(-3.0f,-9.0f,0.0f);
    glVertex3f(-6.0f,-9.0f,0.0f);
    glVertex3f(-6.0f,-12.0f,0.0f);
    glVertex3f(-3.0f,-12.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(-6.0f,-9.0f,0.0f);
    glVertex3f(-9.0f,-9.0f,0.0f);
    glVertex3f(-9.0f,-12.0f,0.0f);
    glVertex3f(-6.0f,-12.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(-9.0f,-9.0f,0.0f);
    glVertex3f(-12.0f,-9.0f,0.0f);
    glVertex3f(-12.0f,-12.0f,0.0f);
    glVertex3f(-9.0f,-12.0f,0.0f);
    glEnd();


//cuarta fila 2 negativa
    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(0.0f,-9.0f,0.0f);
    glVertex3f(3.0f,-9.0f,0.0f);
    glVertex3f(3.0f,-12.0f,0.0f);
    glVertex3f(0.0f,-12.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(3.0f,-9.0f,0.0f);
    glVertex3f(6.0f,-9.0f,0.0f);
    glVertex3f(6.0f,-12.0f,0.0f);
    glVertex3f(3.0f,-12.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(6.0f,-9.0f,0.0f);
    glVertex3f(9.0f,-9.0f,0.0f);
    glVertex3f(9.0f,-12.0f,0.0f);
    glVertex3f(6.0f,-12.0f,0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3f(9.0f,-9.0f,0.0f);
    glVertex3f(12.0f,-9.0f,0.0f);
    glVertex3f(12.0f,-12.0f,0.0f);
    glVertex3f(9.0f,-12.0f,0.0f);
    glEnd();

}

void Fondo(void)
{
    //CUADRO DE FONDO	
    glBegin(GL_QUADS);
    glColor3f(0.64, 0.46, 0.0125);
    glVertex3d(0.766,0.8,-1);
    glVertex3d(0.900,0.2,0.03);
    glVertex3d(-0.900,0.2,0.03);
    glVertex3d(-0.766,0.8,-1);
    glEnd();
}
void cuadro(void)
{
    glPushMatrix();
    glShadeModel(GL_SMOOTH);
    glTranslatef(0.0,2.8,1.05);
    glRotated(30.0, 0.0, 0.0, 1.0);
    glColor3f(0.0,1.0,0.0);
    glutSolidCube (5.5);
    glPopMatrix();
}
void cono(void)
{
	
	glPushMatrix();
	glShadeModel(GL_SMOOTH);
    glScalef(0.6,0.6,0.6);
    glTranslatef(-20.2,8.8,8.0);
    glColor3f(0.60,0.20,1.0);
    glutSolidCone (8.0, -12.0,15.0,10.0);
    glPopMatrix();
}
void circulo(void)
{
	glPushMatrix();
	glShadeModel(GL_SMOOTH);
    glScalef(0.5,0.5,0.5);
    glTranslatef(20.2,4.5,1.05);
    glColor3f(0.80,0.20,0.10);
    glutSolidSphere (8.0,25,25);
    glPopMatrix();
}

 
void display(void)
{
    glClear(GL_COLOR_BUFFER_BIT);
	glLoadIdentity();
	glScalef(15.0,15.0,15.0);
	Fondo();
    glFlush();
    glTranslatef(0.0,-0.05,0.0);
	glScalef(0.072,0.062,0.09);

	glFlush();
    
    glPushMatrix();
	piso();
    glPopMatrix();

	glPushMatrix();
	cuadro();
    glPopMatrix();
    
    glPushMatrix();
    cono();
    glPopMatrix();
   
    glPushMatrix();
    circulo();
    glPopMatrix();
    
    glPushMatrix();
    
    glShadeModel(GL_SMOOTH);
	glTranslatef(6.2,4.5,5.0);
   glBegin(GL_POLYGON);
    GLint arco=75;
    GLfloat pi=3.1415926535898;
   glColor3f(0.0f,0.8f,0.75f);
   // dibujamos la circunferencia de 0.25 de radio entre los cuatro triangulos
    for(float i=0;i<arco;i++)
    {
		GLfloat angle= (2*pi*i)/arco;
		glVertex2f(cos(angle)*4+3,sin(angle)*4-5);
    }
   glEnd();
    
    glPopMatrix();
    
    glPushMatrix();
    glShadeModel(GL_SMOOTH);
    glRotated(-150.0, 0.0, 0.0, 1.0);
	glTranslatef(-8.0,-14.0,10.0);
    glBegin(GL_QUADS);
    glColor3f(0.0f,0.8f,0.75f);
    glVertex3f(0.0f,0.0f,0.0f);
    glVertex3f(0.0f,8.0f,0.0f);
    glVertex3f(8.0f,8.0f,0.0f);
    glVertex3f(8.0f,0.0f,0.0f);
    glEnd();
    glPopMatrix();
    
    
      glPushMatrix();
    
    glShadeModel(GL_SMOOTH);
	glTranslatef(6.2,4.5,7.0);
   glBegin(GL_POLYGON);
    //GLint arco=75;
    //GLfloat pi=3.1415926535898;
   glColor3f(0.0f,0.8f,0.75f);
   // dibujamos la circunferencia de 0.25 de radio entre los cuatro triangulos
    for(float i=0;i<arco;i++)
    {
		GLfloat angle= (2*pi*i)/arco;
		glVertex2f(cos(angle)*4-18,sin(angle)*4-3);
    }
   glEnd();
    
    glPopMatrix();
    
   	glFlush();
	glutSwapBuffers();
}

void init(void)
{
	glClearColor(1.0, 1.0, 1.0, 1.0);
	//glShadeModel(GL_FLAT);
	
// Ubicamos la fuente de luz en el punto
    GLfloat light_position[] = { -10.0, 10.0, 1.0, 0.0 };
	//GLfloat luz_ambiental[] = { 0.2, 0.2, 0.2, 1.0 };
	  glMatrixMode(GL_PROJECTION);
	  glLoadIdentity();
	glMatrixMode(GL_MODELVIEW);
	
// Activamos la fuente de luz
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);


    glEnable(GL_COLOR_MATERIAL);
    glEnable(GL_NORMALIZE);
    
    

	glLightfv(GL_LIGHT0,GL_POSITION,light_position);
// Queremos que se dibujen las caras frontales
// y con un color solido de relleno.
    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	glLoadIdentity();

}



void reshape(int w, int h)
{
    glClearColor(1,1,1,1.1);
	glViewport(0,0,(GLsizei)w,(GLsizei)h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(80.0f, (GLfloat)w/(GLfloat)h, 0.0f, 1.0f);
    gluLookAt(0.0,-30.0,-9.0,0.0,3.0,-1.0,0.0,1.0,0.0);	
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize (1000, 800);//tamaño de la ventana
    glutInitWindowPosition (300, 100);//posicion de la ventana en la pantalla
    glutCreateWindow ("Tablero");//nombre de la ventana
    init ();
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutMainLoop();
    return 0;
}
