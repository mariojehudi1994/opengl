#include <stdio.h>
#include <GL/gl.h>
#include <GL/glut.h>

void init(void)
{
	GLfloat light_position[] = { -5.0, 50.0, 5.0, 0.0 };
// Activamos la fuente de luz
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0); //Activamos las luces en 0
    glDepthFunc(GL_LESS); //comparación de profundidad
    glEnable(GL_DEPTH_TEST); //activa GL_DEPTH_TEST
    glLightfv(GL_LIGHT0,GL_POSITION,light_position);
// Queremos que se dibujen las caras frontales
// y con un color solido de relleno.
    glPolygonMode(GL_FRONT, GL_FILL);

}
//funcion que controla los matariales 
void color(float q, float w, float e, float r, float t, float y, float u, float i, float o, float p)
{
	
GLfloat mat_ambient[] = { q, w, e, p };
GLfloat mat_diffuse[] = { r, t, y, p };
GLfloat mat_specular[] = { u, i, o, p };
GLfloat shine[] = {27.8974f};

glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient);
glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
glMaterialfv(GL_FRONT, GL_SHININESS, shine);

}
void cubo(void)
{
	glPushMatrix();
    // LADO DERECHO
    glBegin(GL_POLYGON);
    
    color(0.45f, 0.45, 0.45f,0.5f, 0.5f, 0.5f,0.7f, 0.7f, 0.7f,0.078125f);
    glVertex3f( 0.3, -0.3, 0.3 );
    glVertex3f( 0.3,  0.3, 0.3 );
    glVertex3f(-0.3,  0.3, 0.3 );
    glVertex3f(-0.3, -0.3, 0.3 );
    glEnd();
    glPopMatrix();

    // LADO IZQUIERDO
    glBegin(GL_POLYGON);
    
    color(0.05f, 0.05, 0.05f,0.5f, 0.5f, 0.5f,0.7f, 0.7f, 0.7f,0.078125f);
    glColor3f(0.25,  0.25,  0.25);
    glVertex3f(-0.3, -0.3,  0.3 );
    glVertex3f(-0.3,  0.3,  0.3 );
    glVertex3f(-0.3,  0.3, -0.3 );
    glVertex3f(-0.3, -0.3, -0.3 );
    glEnd();

    //mesa
    
    glBegin(GL_POLYGON);
    
    color(0.9999f, 0.9999, 0.9999f,0.5f, 0.5f, 0.5f,0.7f, 0.7f, 0.7f,0.078125f);
    glVertex3f(0.1,  -0.05,  0.2);
    glVertex3f(0.1,  -0.05, -0.2 );
    glVertex3f(-0.3,  -0.10, -0.1);
    glVertex3f(-0.3,  -0.10,  0.3);
    glEnd();

    //base del cubo
    glBegin(GL_POLYGON);
    
    color(0.9999f, 0.9999, 0.9999f,0.5f, 0.5f, 0.5f,0.7f, 0.7f, 0.7f,0.078125f);
    glVertex3f(0.3, -0.3, -0.3 );
    glVertex3f(0.3, -0.3,  0.3 );
    glVertex3f(-0.3, -0.3,  0.3 );
    glVertex3f(-0.3, -0.3, -0.3 );
    glEnd();
    
    //patas de la mesa
    // para de la derecha
    glLineWidth (12.0);
    glBegin(GL_LINE_STRIP);
    
    color(0.05f, 0.05, 0.05f,0.5f, 0.5f, 0.5f,0.7f, 0.7f, 0.7f,0.078125f);
    glVertex3f(0.05f,-0.09f, 0.2f);
    glVertex3f(0.05f,-0.5f, 0.2f); 
    glEnd();
    
    //pata de enfrente
    glLineWidth (12.0);
    glBegin(GL_LINE_STRIP);
    
    color(0.45f, 0.45, 0.45f,0.5f, 0.5f, 0.5f,0.7f, 0.7f, 0.7f,0.078125f);
    glVertex3f(0.05f,-0.09f, -0.12f);
    glVertex3f(0.05f,-0.3f, -0.12f); 
    glEnd();

    //pata de atras
    glLineWidth (12.0);
    glBegin(GL_LINE_STRIP);
    
    color(0.05f, 0.05, 0.05f,0.5f, 0.5f, 0.5f,0.7f, 0.7f, 0.7f,0.078125f);
    glVertex3f(-0.24f,-0.1f, 0.2f);
    glVertex3f(-0.24f,-0.3f, 0.2f); 
    glEnd();
    
    //pata izquierda
    glLineWidth (12.0);
    glBegin(GL_LINE_STRIP);
    
    color(0.45f, 0.45, 0.45f,0.5f, 0.5f, 0.5f,0.7f, 0.7f, 0.7f,0.078125f);
    glVertex3f(-0.2f,-0.09f, -0.12f);
    glVertex3f(-0.2f,-0.3f, -0.12f); 
    glEnd();

}
void display()
{
	GLfloat position[] = { 0.0, 0.0, 1.5, 1.0 };
    // "Limpiamos" el frame buffer con el color de "Clear", en este
    // caso negro.
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glMatrixMode( GL_MODELVIEW_MATRIX );
     

    // Resetear transformaciones
    glLoadIdentity();
    // Rotacion de 25 grados en torno al eje x
    glRotated(-25.0, 9.0, 0.0, 0.0);
    // Rotacion de -30 grados en torno al eje y
    glRotated(30.0, 0.0, 1.0, 0.0);
    cubo();
    glPushMatrix();
    glTranslatef(0.03,-0.01,-0.05);
    
    color(0.329412f, 0.223529f, 0.027451f,0.780392f, 0.568627f, 0.113725f,0.992157f, 0.941176f, 0.807843f,1.0f);
    glutSolidTeapot(0.05);
    glPopMatrix();
    
    glFlush();
    glutSwapBuffers();

}

int main(int argc, char* argv[])
{

    //  Inicializar los parámetros GLUT y de usuario proceso
    glutInit(&argc,argv);

    // Solicitar ventana con color real y doble buffer con Z-buffer
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize (800, 600);
    glutInitWindowPosition (0, 0);
    // Crear ventana
    glutCreateWindow("Mesa_Tetera");

    // Habilitar la prueba de profundidad de Z-buffer
    glEnable(GL_DEPTH_TEST);
    init();

    // Funciones de retrollamada
    glutDisplayFunc(display);
    // Pasar el control de eventos a GLUT
    glutMainLoop();

    // Regresar al sistema operativo
    return 0;

}
