#include <GL/gl.h>
#include <GL/glut.h>
#include <stdlib.h>

//Definimos variables
double rotate_y=0;
double rotate_x=0;
double rotate_z=0;


GLfloat X = 0.0f;
GLfloat Y = 0.0f;
GLfloat Z = 0.0f;
GLfloat scale = 1.0f;


// Propiedades del material

    GLfloat mat_ambient[] = { 0.05, 0.05, 0.0,1.0f };
    GLfloat mat_diffuse[] = { 0.5, 0.5, 0.4, 1.0f };
    GLfloat mat_specular[] = { 0.7, 0.7,0.04, 1.0f };
    GLfloat shine[] = {0.07812};

void init(void)
{
	// Ubicamos la fuente de luz en el punto
    GLfloat light_position[] = { 100.0, 100.0, 100.0, 0.0 };
// Activamos la fuente de luz
glEnable(GL_LIGHTING);
glEnable(GL_LIGHT0); //Activamos las luces en 0
glDepthFunc(GL_LESS); //comparación de profundidad
glEnable(GL_DEPTH_TEST); //activa GL_DEPTH_TEST

glLightfv(GL_LIGHT0,GL_POSITION,light_position);
// Queremos que se dibujen las caras frontales
// y con un color solido de relleno.
    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);

}
void reshape(int w, int h)
{
glViewport(0, 0, (GLsizei) w, (GLsizei) h);
// Activamos la matriz de proyeccion.
glMatrixMode(GL_PROJECTION);
// "limpiamos" esta con la matriz identidad.
glLoadIdentity();
// Usamos proyeccion ortogonal
glOrtho(-2, 2, -2, 2, -2, 2);
// Activamos la matriz de modelado/visionado.
glMatrixMode(GL_MODELVIEW);
// "Limpiamos" la matriz
glLoadIdentity();
}



void display(void)
{


// "Limpiamos" el frame buffer con el color de "Clear", en este
// caso negro.
glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
glMatrixMode( GL_MODELVIEW_MATRIX );
glLoadIdentity();
// Rotar en el eje X,Y
glRotatef( rotate_x, 1.0, 0.0, 0.0 );
glRotatef( rotate_y, 0.0, 1.0, 0.0 );
glPushMatrix();



//set material
glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, mat_ambient);
glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, mat_diffuse);
glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, mat_specular);
glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, shine);


//Dibujamos un triangulo
glShadeModel(GL_SMOOTH);
glBegin(GL_QUADS);
glNormal3f(-1.0f, 0.0f, 1.0f);
glVertex3d(-1,0,-1);
glNormal3f(-1.0f, 0.0f, 1.0f);
glVertex3d(-1,0,1);
glNormal3f(-1.0f, 0.0f, 1.0f);
glVertex3d(1,0,1);
glNormal3f(-1.0f, 0.0f, 1.0f);
glVertex3d(1,0,-1);
glEnd();


//lado 1
glShadeModel(GL_SMOOTH);
glBegin(GL_TRIANGLES);
glNormal3f(-1.0f, 0.0f, 1.0f);
glVertex3d(0,1,0);
glNormal3f(-1.0f, 0.0f, 1.0f);
glVertex3d(1,0,-1);
glNormal3f(-1.0f, 0.0f, 1.0f);
glVertex3d(1,0,1);
glEnd();

//lado 2
glShadeModel(GL_SMOOTH);
glBegin(GL_TRIANGLES);
glNormal3f(-1.0f, 0.0f, 1.0f);
glVertex3d(0,1,0);
glNormal3f(-1.0f, 0.0f, 1.0f);
glVertex3d(1,0,1);
glNormal3f(-1.0f, 0.0f, 1.0f);
glVertex3d(-1,0,1);
glEnd();

//lado 3
glShadeModel(GL_SMOOTH);
glBegin(GL_TRIANGLES);
glNormal3f(-1.0f, 0.0f, 1.0f);
glVertex3d(0,1,0);
glNormal3f(-1.0f, 0.0f, 1.0f);
glVertex3d(-1,0,1);
glNormal3f(-1.0f, 0.0f, 1.0f);
glVertex3d(-1,0,-1);
glEnd();

//lado 4
glShadeModel(GL_SMOOTH);
glBegin(GL_TRIANGLES);
glNormal3f(-1.0f, 0.0f, 1.0f);
glVertex3d(0,1,0);
glNormal3f(-1.0f, 0.0f, 1.0f);
glVertex3d(-1,0,-1);
glNormal3f(-1.0f, 0.0f, 1.0f);
glVertex3d(1,0,-1);
glEnd();


glFlush();
}
void specialKeys( int key, int x, int y )
{

    //  Flecha derecha: aumentar rotación 7 grados
    if (key == GLUT_KEY_RIGHT)
        rotate_y += 7;

    //  Flecha izquierda: rotación en eje Y negativo 7 grados
    else if (key == GLUT_KEY_LEFT)
        rotate_y -= 7;
    //  Flecha arriba: rotación en eje X positivo 7 grados
    else if (key == GLUT_KEY_UP)
        rotate_x += 7;
    //  Flecha abajo: rotación en eje X negativo 7 grados
    else if (key == GLUT_KEY_DOWN)
        rotate_x -= 7;
        
    //  Solicitar actualización de visualización
    glutPostRedisplay();
}

void keyboard(unsigned char key, int x, int y)
{
    //control de teclas que cambian los colores de la piramide
    switch (key)
    {  
      case '1':
      //jade
           mat_ambient[0] =0.135f;
           mat_ambient[1] =0.2225f;
           mat_ambient[2] =0.1575f;
           mat_ambient[3] =0.1;
           
           mat_diffuse[0] =0.54f;
           mat_diffuse[1] =0.89f;
           mat_diffuse[2] = 0.63f;
           mat_diffuse[3] =0.1f;
           
           mat_specular[0] =0.316228f;
           mat_specular[1] =0.316228f;
           mat_specular[2] =0.316228;
           mat_specular[3] =0.1f;
           
           shine[0] = 0.1f; 
      break;
      
      case '2':
      //chrome
           mat_ambient[0] =0.25f;
           mat_ambient[1] =0.25f;
           mat_ambient[2] =0.25f;
           mat_ambient[3] =0.1f;
           
           mat_diffuse[0] =0.4f;
           mat_diffuse[1] =0.4f;
           mat_diffuse[2] = 0.4f;
           mat_diffuse[3] =0.1f;
           
           mat_specular[0] =0.774597f;
           mat_specular[1] =0.774597f;
           mat_specular[2] =0.774597f;
           mat_specular[3] =0.1f;
           
           shine[0] = 0.6f; 
     
      break;
      case '3':
      //cyan plastic
           mat_ambient[0] =0.0f;
           mat_ambient[1] =0.1f;
           mat_ambient[2] =0.06f;
           mat_ambient[3] =0.1f;
           
           mat_diffuse[0] =0.0f;
           mat_diffuse[1] =0.50980392f;
           mat_diffuse[2] =0.50980392f;
           mat_diffuse[3] =0.1f;
           
           mat_specular[0] =0.50196078f;
           mat_specular[1] =0.50196078f;
           mat_specular[2] =0.50196078f;
           mat_specular[3] =0.1f;
           
           shine[0] = 0.25f; 
      
      break;
      case '4':
      //red plastic
           mat_ambient[0] =0.0f;
           mat_ambient[1] =0.0f;
           mat_ambient[2] =0.0f;
           mat_ambient[3] =0.1f;
           
           mat_diffuse[0] =0.5f;
           mat_diffuse[1] =0.0f;
           mat_diffuse[2] =0.0f;
           mat_diffuse[3] =0.1f;
           
           mat_specular[0] =0.7f;
           mat_specular[1] =0.6f;
           mat_specular[2] =0.6f;
           mat_specular[3] =0.1f;
           
           shine[0] = 0.25f; 
     
      break;
      case '5':
      //ruby
           mat_ambient[0] =0.1745f;
           mat_ambient[1] =0.01175f;
           mat_ambient[2] =0.01175f;
           mat_ambient[3] =0.1f;
           
           mat_diffuse[0] =0.61424f;
           mat_diffuse[1] =0.04136f;
           mat_diffuse[2] =0.04136f;
           mat_diffuse[3] =0.1f;
           
           mat_specular[0] =0.727811f;
           mat_specular[1] =0.626959f;
           mat_specular[2] =0.626959f;
           mat_specular[3] =0.1f;
           
           shine[0] = 0.6f; 
     
      break;
    }
    glutPostRedisplay();
}
int main(int argc, char **argv)
{
// Inicializo OpenGL
glutInit(&argc, argv);
// Activamos buffer simple y colores del tipo RGB
glutInitDisplayMode (GLUT_RGB | GLUT_DEPTH);
// Definimos una ventana de medidas 800 x 600 como ventana
// de visualizacion en pixels
glutInitWindowSize (800, 600);
// Posicionamos la ventana en la esquina superior izquierda de
// la pantalla.
glutInitWindowPosition (0, 0);
// Creamos literalmente la ventana y le adjudicamos el nombre que se
// observara en su barra de titulo.
glutCreateWindow ("PIRAMIDE");
// Inicializamos el sistema
init();
glutDisplayFunc(display);
glutReshapeFunc(reshape);

glutSpecialFunc(specialKeys);
glutKeyboardFunc(keyboard);
glutMainLoop();
return 0;
}
